/*
 * $Id: PassThroughComponent.java 12565 2008-08-26 13:49:21Z dirk.olmes $
 * --------------------------------------------------------------------------------------
 * Copyright (c) MuleSource, Inc.  All rights reserved.  http://www.mulesource.com
 *
 * The software in this package is published under the terms of the CPAL v1.0
 * license, a copy of which has been included with this distribution in the
 * LICENSE.txt file.
 */

package org.mule.component.simple;

import org.mule.api.MuleEvent;
import org.mule.component.AbstractComponent;

/**
 * <code>PassThroughComponent</code> will simply return the payload back as the
 * result. This typically you don't need to specify this, since it is used by
 * default.
 */
public class PassThroughComponent extends AbstractComponent
{

    // @Override
    protected Object doInvoke(MuleEvent event) throws Exception
    {
        event.transformMessage();
        return event.getMessage();
    }

}
