/*
 * $Id: BindingCollection.java 13410 2008-11-22 15:15:42Z rossmason $
 * --------------------------------------------------------------------------------------
 * Copyright (c) MuleSource, Inc.  All rights reserved.  http://www.mulesource.com
 *
 * The software in this package is published under the terms of the CPAL v1.0
 * license, a copy of which has been included with this distribution in the
 * LICENSE.txt file.
 */

package org.mule.api.routing;

/**
 * <code>BindingCollection</code> manages a collection of component bindings.
 */
public interface BindingCollection extends RouterCollection
{
    // no additional methods
}
