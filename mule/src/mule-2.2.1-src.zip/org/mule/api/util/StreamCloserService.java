/*
 * $Id: StreamCloserService.java 12425 2008-07-29 20:17:53Z tcarlson $
 * --------------------------------------------------------------------------------------
 * Copyright (c) MuleSource, Inc.  All rights reserved.  http://www.mulesource.com
 *
 * The software in this package is published under the terms of the CPAL v1.0
 * license, a copy of which has been included with this distribution in the
 * LICENSE.txt file.
 */

package org.mule.api.util;

import org.mule.api.context.MuleContextAware;

/**
 * Simple service to close streams of different types.
 */
public interface StreamCloserService extends MuleContextAware
{

    void closeStream(Object stream);

}
